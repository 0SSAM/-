# Backend

Generated stub for al-shawwa-pharmacy-ecommerce. Run with `node server/index.js` after wiring an Express server.