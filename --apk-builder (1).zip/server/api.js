بالتأكيد، سأقوم بإنشاء ملف `server/api.js` يتضمن جميع المعالجات (handlers) لنقاط النهاية المطلوبة، مع استخدام بيانات وهمية مخزنة في الذاكرة ومحاكاة لآلية المصادقة والتحقق من الصلاحيات بشكل بسيط لضمان قابلية القراءة والفهم.

```javascript
// server/api.js
const express = require('express');
const router = express.Router();

// --- وظيفة مساعدة لتوليد معرفات فريدة (تستخدم لأغراض المحاكاة) ---
const generateId = () => Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);

// --- مخزن البيانات الوهمية في الذاكرة ---
let users = [
  { id: 'usr_001', email: 'customer@example.com', passwordHash: 'hashedpassword123', name: 'زبون تجريبي', address: '123 شارع العملاء', phone: '0501234567', role: 'customer' },
  { id: 'usr_002', email: 'admin@example.com', passwordHash: 'hashedpassword456', name: 'مسؤول تجريبي', address: '456 شارع الإدارة', phone: '0557654321', role: 'admin' },
];

let categories = [
  { id: 'cat_001', name: 'الفيتامينات', description: 'فيتامينات أساسية لدعم الصحة', imageUrl: 'https://picsum.photos/id/20/300/200' },
  { id: 'cat_002', name: 'مسكنات الألم', description: 'أدوية لتخفيف الألم والحمى', imageUrl: 'https://picsum.photos/id/21/300/200' },
  { id: 'cat_003', name: 'العناية بالبشرة', description: 'منتجات للحفاظ على بشرة صحية', imageUrl: 'https://picsum.photos/id/22/300/200' },
];

let products = [
  { id: 'prd_001', name: 'فيتامين سي 1000 ملغ', description: 'لتعزيز المناعة', price: 15.99, imageUrl: 'https://picsum.photos/id/200/300/200', categoryId: 'cat_001', unitType: 'pack', availableUnits: 100 },
  { id: 'prd_002', name: 'ايبوبروفين 200 ملغ', description: 'مسكن للألم وخافض للحرارة', price: 8.50, imageUrl: 'https://picsum.photos/id/201/300/200', categoryId: 'cat_002', unitType: 'pack', availableUnits: 50 },
  { id: 'prd_003', name: 'كريم مرطب', description: 'لترطيب البشرة الجافة', price: 25.00, imageUrl: 'https://picsum.photos/id/202/300/200', categoryId: 'cat_003', unitType: 'pack', availableUnits: 75 },
  { id: 'prd_004', name: 'باراسيتامول 500 ملغ', description: 'لتخفيف الصداع', price: 6.75, imageUrl: 'https://picsum.photos/id/203/300/200', categoryId: 'cat_002', unitType: 'pack', availableUnits: 120 },
  { id: 'prd_005', name: 'زيت السمك أوميغا 3', description: 'لصحة القلب والدماغ', price: 22.99, imageUrl: 'https://picsum.photos/id/204/300/200', categoryId: 'cat_001', unitType: 'pack', availableUnits: 80 },
];

let cartItems = []; // { id, userId, productId, quantity, unitType }
let orders = []; // { id, userId, orderDate, status, totalAmount, shippingAddress, paymentMethod }
let orderItems = []; // { id, orderId, productId, quantity, unitPrice, unitType }
let consultationFeedback = []; // { id, userId, type, subject, message, status, contactInfo }

// --- محاكاة لحالة المستخدم الحالي المسجل للدخول ---
let currentUser = null; // يمثل المستخدم الذي سجل الدخول حاليًا (لأغراض المحاكاة)

// --- وظائف Middleware للمصادقة والتحقق من الصلاحيات (محاكاة) ---
const authenticateUser = (req, res, next