import React, { useState } from 'react';

export default function AuthPage() {
  const [mode, setMode] = useState<'login' | 'signup' | 'reset'>('login');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Placeholder for form submission logic
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm py-4">
        <div className="container mx-auto px-6 md:px-0 flex items-center justify-between">
          <h1 className="text-2xl font-semibold text-gray-800">HealthShop</h1>
          <nav className="flex space-x-4">
            <button
              onClick={() => setMode('login')}
              className={`text-sm font-medium ${
                mode === 'login' && 'border-b-2 border-[#0D6EFD] text-[#0D6EFD]'
              }`}
            >
              تسجيل الدخول
            </button>
            <button
              onClick={() => setMode('signup')}
              className={`text-sm font-medium ${
                mode === 'signup' && 'border-b-2 border-[#0D6EFD] text-[#0D6EFD]'
              }`}
            >
              إنشاء حساب
            </button>
            <button
              onClick={() => setMode('reset')}
              className={`text-sm font-medium ${
                mode === 'reset' && 'border-b-2 border-[#0D6EFD] text-[#0D6EFD]'
              }`}
            >
              استعادة كلمة المرور
            </button>
          </nav>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex flex-1 items-center justify-center py-12">
        <div className="w-full max-w-md space-y-8 p-8 bg-white rounded-xl shadow-lg">
          {/* Login Form */}
          {mode === 'login' && (
            <form onSubmit={handleSubmit} className="space-y-6">
              <h2 className="text-center text-3xl font-extrabold text-gray-900">
                تسجيل الدخول
              </h2>
              <div className="space-y-4">
                <div>
                  <label htmlFor="login-email" className="block text-sm font-medium text-gray-700">
                    البريد الإلكتروني
                  </label>
                  <input
                    id="login-email"
                    type="email"
                    required
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#0D6EFD] focus:ring-[#0D6EFD]"
                  />
                </div>
                <div>
                  <label htmlFor="login-password" className="block text-sm font-medium text-gray-700">
                    كلمة المرور
                  </label>
                  <input
                    id="login-password"
                    type="password"
                    required
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#0D6EFD] focus:ring-[#0D6EFD]"
                  />
                </div>
              </div>
              <div className="flex items-center justify-between">
                <a href="#" className="text-sm text-[#0D6EFD] hover:underline">
                  نسيت كلمة المرور؟
                </a>
                <button
                  type="submit"
                  className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-[#0D6EFD] hover:bg-[#0B5ed7] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#0D6EFD]"
                >
                  تسجيل الدخول
                </button>
              </div>
            </form>
          )}

          {/* Signup Form */}
          {mode === 'signup' && (