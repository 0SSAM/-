import React from 'react';

export default function OrderTracking() {
  // بيانات وهمية للطلبات
  const currentOrders = [
    {
      id: '123456789',
      date: '2023-10-26',
      status: 'قيد التجهيز',
      statusColor: 'yellow',
      items: 'دواء السكري (عبوتين)، فيتامين د (عبوة واحدة)',
    },
    {
      id: '987654321',
      date: '2023-10-25',
      status: 'في الطريق',
      statusColor: 'green',
      items: 'مستلزمات الإسعافات الأولية (مجموعة كاملة)',
    },
  ];

  const pastOrders = [
    {
      id: '456789012',
      date: '2023-09-15',
      status: 'تم التوصيل',
      statusColor: 'blue',
      items: 'قياس ضغط الدم (جهاز)، شرايط اختبار',
    },
    {
      id: '012345678',
      date: '2023-08-01',
      status: 'ملغي',
      statusColor: 'red',
      items: 'كريم مرطب (200 مل)',
    },
  ];

  // دالة مساعدة لتحديد فئات Tailwind بناءً على لون الحالة
  const getStatusClasses = (color) => {
    switch (color) {
      case 'yellow':
        return 'bg-yellow-100 text-yellow-800';
      case 'green':
        return 'bg-green-100 text-green-800';
      case 'blue':
        return 'bg-blue-100 text-blue-800';
      case 'red':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  // اللون الأزرق الرئيسي (#0D6EFD) سيتم تقريبه إلى فئات Tailwind
  const primaryBlueClasses = 'bg-blue-600 hover:bg-blue-700';
  const primaryBlueBorder = 'border-blue-600';
  const primaryBlueText = 'text-blue-800';

  return (
    <div className="min-h-screen bg-gray-50 p-4 sm:p-6 md:p-8 font-sans text-gray-800">
      {/* رأس الصفحة */}
      <header className="mb-10 text-center">
        <h1 className={`text-4xl sm:text-5xl font-extrabold ${primaryBlueText} mb-3`}>
          متابعة الطلبات
        </h1>
        <p className="text-lg sm:text-xl text-gray-600">
          استعرض حالة طلباتك الحالية والسابقة بكل سهولة وشفافية لضمان راحة بالك.
        </p>
      </header>

      {/* قسم الطلبات الحالية */}
      <section className="mb-12 max-w-7xl mx-auto">
        <h2 className="text-3xl sm:text-4xl font-bold text-gray-700 mb-8 text-right">الطلبات الحالية</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {currentOrders.length > 0 ? (
            currentOrders.map((order) => (
              <div
                key={order.id}
                className={`bg-white rounded-xl shadow-lg p-6 flex flex-col justify-between transform hover:scale-105 transition-all duration-300 border-t-4 ${primaryBlueBorder}`}
              >
                <div>
                  <h3 className="text-xl sm:text-2xl font-bold mb-3 text-right">طلب #{order.id}</h3>
                  <p className="text-sm text-gray-500 mb-4 text-right">
                    <span className="font-semibold">تاريخ الطلب:</span> {order.date}
                  </p>
                  <div className="flex items-center justify-end mb-4">
                    <span className={`${getStatusClasses(order.statusColor)} text-sm font-medium px-3 py-1 rounded-full text-right`}>
                      {order.status}
                    </span>
                    <span className="mr-2 text-gray-600 font-medium">الحالة:</span>
                  </div>
                  <p className="text-gray-700 mb-4 text-right leading-relaxed">
                    <span className="font-semibold">تفاصيل المنتجات:</span> {order.items}
                  </p>
                </div>
                <button
                  className={`${primaryBlueClasses} text-white font-bold py-3 px-6 rounded-lg transition-colors duration-200 w-full mt-4 text-lg`}
                >
                  عرض التفاصيل
                </button>
              </div>
            ))
          ) : (
            <div className="md:col-span-3 text-center py-10 text-gray-500 text-lg">
              لا توجد لديك طلبات حالية في الوقت الحالي.
            </div>
          )}
        </div>
      </section>

      {/* قسم الطلبات السابقة */}
      <section className="max-w-7xl mx-auto">
        <h2 className="text-3xl sm:text-4xl font-bold text-gray-700 mb-8 text-right">الطلبات السابقة</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {pastOrders.length > 0 ? (
            pastOrders.map((order) => (
              <div
                key={order.id}
                className="bg-white rounded-xl shadow-lg p-6 flex flex-col justify-between transform hover:scale-105 transition-all duration-300 border-t-4 border-gray-300"
              >
                <div>
                  <h3 className="text-xl sm:text-2xl font-bold mb-3 text-right">طلب #{order.id}</h3>
                  <p className="text-sm text-gray-500 mb-4 text-right">
                    <span className="font-semibold">تاريخ الطلب:</span> {order.date}
                  </p>
                  <div className="flex items-center justify-end mb-4">
                    <span className={`${getStatusClasses(order.statusColor)} text-sm font-medium px-3 py-1 rounded-full text-right`}>
                      {order.status}
                    </span>
                    <span className="mr-2 text-gray-600 font-medium">الحالة:</span>
                  </div>
                  <p className="text-gray-700 mb-4 text-right leading-relaxed">
                    <span className="font-semibold">تفاصيل المنتجات:</span> {order.items}
                  </p>
                </div>
                <button
                  className="bg-gray-400 hover:bg-gray-500 text-white font-bold py-3 px-6 rounded-lg transition-colors duration-200 w-full mt-4 text-lg"
                >
                  عرض التفاصيل
                </button>
              </div>
            ))
          ) : (
            <div className="md:col-span-3 text-center py-10 text-gray-500 text-lg">
              لا توجد لديك سجل لطلبات سابقة.
            </div>
          )}
        </div>
      </section>
    </div>
  );
}