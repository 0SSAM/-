<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8">
  <title>استشارة – ملاحظات – اقتراحات</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Compatibility with PWA -->
  <link rel="manifest" href="/manifest.json">
  <meta name="theme-color" content="#0D6EFD">
  <!-- Google Fonts: Inter (sans‑serif) -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="/css/styles.css">
  <!-- Icon set (ملف Sprite) -->
  <link rel="stylesheet" href="/css/icons.css">
</head>
<body class="page-consultation">
  <header class="site-header">
    <div class="container">
      <div class="logo"> <a href="/"><img src="/img/logo.svg" alt="لوغو الشركة" width="120"></a></div>
      <div class="contact-info">
        <a href="tel:01015700081" class="btn-cta" aria-label="اتصل بالرقم"><i class="icon-phone"></i> 010 157 000 81</a>
        <a href="https://wa.me/201015700081" target="_blank" class="btn-cta" aria-label="واتساب"><i class="icon-whatsapp"></i> واتساب</a>
      </div>
    </div>
  </header>

  <main class="container mt-4">
    <section class="hero text-align-center">
      <h1 class="mb-2">استشارات دوائية، شكاوى، اقتراحات</h1>
      <p class="lead">نحن نسمعك، ونساعدك في الحصول على أفضل الحلول الصحية.</p>
    </section>

    <section class="form-section">
      <form id="feedbackForm" novalidate>
        <!-- CSRF token hidden input (backend must provide this) -->
        <input type="hidden" name="csrf_token" value="{{csrf_token}}">
       
        <div class="grid-2">
          <div class="form-group">
            <label for="name">الاسم الكامل</label>
            <input type="text" id="name" name="name" placeholder="أدخل اسمك الكامل" required>
          </div>

          <div class="form-group">
            <label for="mobile">رقم الجوال</label>
            <input type="tel" id="mobile" name="mobile"
                   placeholder="0101 570 0081" pattern="^010\\d{8}$"
                   title="مثال: 01015700081" required>
          </div>
        </div>

        <div class="grid-2 mt-1">
          <div class="form-group">
            <label for="email">البريد الإلكتروني</label>
            <input type="email" id="email" name="email"
                   placeholder="example@example.com" required>
          </div>

          <div class="form-group">
            <label for="category">الفئة</label>
            <select id="category" name="category" required>
              <option value="" disabled selected>اختر الفئة</option>
              <option value="consultation">استشارة دوائية</option>
              <option value="complaint">شكوى</option>
              <option value="suggestion">اقتراح</option>
            </select>
          </div>
        </div>

        <div class="form-group mt-1">
          <label for="message">الرسالة</label>
          <textarea id="message" name="message" rows="4"
                    placeholder="اكتب تفاصيل طلبك أو اقتراحك" required></textarea>
        </div>

        <div class="form-actions text-align-center mt-2">
          <button type="submit" class="btn-primary btn-submit">
            <i class="icon-send"></i> أرسِل
          </button>
        </div>

        <div id="feedbackMessage" class="hidden"></div>
      </form>
    </section>
  </main>

  <footer class="site-footer mt-4 py-2">
    <div class="container text-align-center">
      © 2026 {{companyName}} – جميع الحقوق محفوظة
    </div>
  </footer>

  <script src="/js/app.js" defer></script>
</body>
</html>

export default function ConsultationFeedback() { return null; }