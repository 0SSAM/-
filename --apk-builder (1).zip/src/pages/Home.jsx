```jsx
import React from "react";

const categories = [
  { name: "أدوية", icon: "💊", route: "/medicines" },
  { name: "تجميل", icon: "💄", route: "/beauty" },
  { name: "مستلزمات طبية", icon: "🩺", route: "/medical-supplies" },
  { name: "أم وطفل", icon: "👶", route: "/mother-child" },
];

const quickLinks = [
  { label: "الصفحة الرئيسية", href: "/" },
  { label: "عربة التسوق", href: "/cart" },
  { label: "حسابي", href: "/profile" },
  { label: "الدعم", href: "/support" },
];

const featuredProducts = [
  { id: 1, name: "أحد المنتجات", price: "$12.99", img: "/placeholder1.jpg" },
  { id: 2, name: "منتج رائع", price: "$24.49", img: "/placeholder2.jpg" },
  { id: 3, name: "منتج ممتاز", price: "$9.99", img: "/placeholder3.jpg" },
  { id: 4, name: "منتج مميز", price: "$19.99", img: "/placeholder4.jpg" },
];

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gray-50 text-gray-800">
      {/* Header with Search */}
      <header className="bg-white shadow-sm py-4">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between">
          <h1 className="text-2xl font-semibold text-[#0D6EFD]">
            اكتشف منتجاتنا المميزة
          </h1>
          <form className="mt-4 sm:mt-0 w-full sm:w-auto">
            <input
              type="search"
              placeholder="ابحث عن المنتجات..."
              className="w-full sm:w-64 p-2 rounded border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#0D6EFD]"
            />
          </form>
        </div>
      </header>

      {/* Quick Links */}
      <nav className="bg-[#0D6EFD] mt-2">
        <ul className="max-w-7xl mx-auto flex flex-wrap justify-center gap-2 py-2 px-4 sm:px-6">
          {quickLinks.map((link) => (
            <li key={link.href}>
              <a
                href={link.href}
                className="text-white hover:text-[#0D6EFD] hover:bg-white transition duration-200 rounded px-4 py-2"
              >
                {link.label}
              </a>
            </li>
          ))}
        </ul>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Categories */}
        <section aria-label="Categories" className="mb-12">
          <h2 className="text-xl font-semibold mb-4 text-gray-700">الفئات الرئيسية</h2>
          <ul className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {categories.map((category) => (
              <li key={category.name}>
                <a
                  href={category.route}
                  className="flex items-center justify-center gap-2 bg-white p-4 rounded shadow hover:bg-[#0D6EFD]/10 transition"
                >
                  <span className="text-2xl">{category.icon}</span>
                  <span className="text-gray-800 font-medium">{category.name}</span>
                </a>
              </li>
            ))}
          </ul>
        </section>

        {/* Featured Products */}
        <section aria-label="Featured Products" className="mb-12">
          <h2 className="text-xl font-semibold mb-4 text-gray-700">المنتجات المميزة</h2>
          <ul className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-6">
            {featuredProducts.map((product) => (
              <li key={product.id}>
                <div className="bg-white rounded shadow hover:shadow-lg transition duration-200">
                  <img
                    src={product.img}
                    alt={product.name}
                    className="w-full h-48 object-cover rounded-t"
                  />
                  <div className="p-4">
                    <h3 className="text-sm font-medium text-gray-900">{product.name}</h3>
                    <p className="text-sm text-gray-600 mt-1">{product.price}</p>
                    <button
                      type="button"
                      className="mt-3 inline-flex items-center justify-center px-3 py-2 text-xs font-medium leading-4