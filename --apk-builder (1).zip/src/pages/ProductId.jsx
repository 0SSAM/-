import React from 'react';

export default function ProductDetail() {
  const productName = "كمامات طبية عالية الجودة N95";
  const productDescription = "كمامات N95 طبية معتمدة، توفر حماية فائقة من الجسيمات المحمولة جواً والفيروسات. مصممة لتوفير أقصى درجات الراحة والتنفس السهل أثناء الاستخدام المطول. مثالية للاستخدام في البيئات الطبية واليومية لضمان سلامتك وسلامة من حولك.";
  const productPrice = "120.00 ر.س";
  const mainImage = "https://via.placeholder.com/600x400/0D6EFD/FFFFFF?text=Product+Image"; // صورة توضيحية للمنتج باللون الرئيسي
  const galleryImages = [
    "https://via.placeholder.com/100x70/0D6EFD/FFFFFF?text=صورة+1",
    "https://via.placeholder.com/100x70/0D6EFD/FFFFFF?text=صورة+2",
    "https://via.placeholder.com/100x70/0D6EFD/FFFFFF?text=صورة+3",
  ];

  return (
    <div className="min-h-screen bg-gray-50 font-sans text-gray-800 antialiased">
      <div className="container mx-auto px-4 py-8 md:py-12 max-w-7xl">
        <div className="flex flex-col md:flex-row gap-8 lg:gap-12 bg-white p-6 md:p-8 rounded-lg shadow-xl">
          {/* معرض صور المنتج */}
          <div className="md:w-1/2 lg:w-3/5 flex flex-col items-center">
            <img
              src={mainImage}
              alt={productName}
              className="w-full h-auto object-cover rounded-lg shadow-md mb-4 max-h-96"
            />
            <div className="flex gap-3 overflow-x-auto pb-2 justify-center">
              {galleryImages.map((img, index) => (
                <img
                  key={index}
                  src={img}
                  alt={`${productName} صورة مصغرة ${index + 1}`}
                  className="w-24 h-16 object-cover rounded-md border-2 border-gray-200 hover:border-blue-700 cursor-pointer transition-all duration-200"
                />
              ))}
            </div>
          </div>

          {/* تفاصيل المنتج */}
          <div className="md:w-1/2 lg:w-2/5 flex flex-col">
            <h1 className="text-3xl md:text-4xl font-extrabold text-gray-900 mb-3 leading-tight">
              {productName}
            </h1>
            <p className="text-2xl font-bold text-blue-700 mb-4">{productPrice}</p>

            <div className="mb-6">
              <h2 className="text-lg font-semibold text-gray-800 mb-2">الوصف</h2>
              <p className="text-gray-600 leading-relaxed text-base">
                {productDescription}
              </p>
            </div>

            {/* خيارات وحدة البيع */}
            <div className="mb-6">
              <h2 className="text-lg font-semibold text-gray-800 mb-2">خيارات وحدة البيع</h2>
              <div className="flex flex-wrap gap-3">
                <button className="px-5 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200">
                  عبوة (10 قطع)
                </button>
                <button className="px-5 py-2 border border-blue-700 bg-blue-700 text-white rounded-lg hover:bg-blue-800 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200">
                  قطعة واحدة
                </button>
              </div>
            </div>

            {/* تحديد الكمية */}
            <div className="mb-6">
              <h2 className="text-lg font-semibold text-gray-800 mb-2">الكمية</h2>
              <div className="flex items-center space-x-3">
                <button className="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg text-xl hover:bg-gray-300 focus:outline-none focus:ring-2 focus:ring-gray-400">-</button>
                <span className="text-xl font-medium text-gray-900">1</span>
                <button className="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg text-xl hover:bg-gray-300 focus:outline-none focus:ring-2 focus:ring-gray-400">+</button>
              </div>
            </div>

            {/* زر الإضافة للسلة */}
            <div className="mt-auto pt-4">
              <button
                className="w-full text-white py-3 px-6 rounded-lg text-lg font-semibold hover:opacity-90 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all duration-300 shadow-lg"
                style={{ backgroundColor: '#0D6EFD' }}
              >
                أضف إلى السلة
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}