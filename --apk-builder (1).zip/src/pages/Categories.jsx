import React from 'react';

export default function ProductCategories() {
  const categories = [
    {
      name: 'أدوية',
      description: 'اكتشف مجموعتنا الواسعة من الأدوية والعلاجات الموثوقة التي تلبي احتياجاتك الصحية.',
      iconChar: '💊', // Placeholder icon
    },
    {
      name: 'تجميل',
      description: 'منتجات العناية بالبشرة والشعر ومستحضرات التجميل الفاخرة التي تعزز جمالك الطبيعي.',
      iconChar: '✨', // Placeholder icon
    },
    {
      name: 'مستلزمات طبية',
      description: 'أجهزة ومستلزمات طبية عالية الجودة للاستخدام المنزلي والمهني، بضمان أفضل المعايير.',
      iconChar: '🩺', // Placeholder icon
    },
    {
      name: 'أم وطفل',
      description: 'كل ما تحتاجه الأم والطفل من رعاية ومنتجات أساسية لضمان نمو صحي وسعيد.',
      iconChar: '👶', // Placeholder icon
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col items-center py-12 px-4 sm:px-6 lg:px-8 font-sans text-right">
      <div className="max-w-7xl mx-auto w-full">
        <h1 className="text-4xl sm:text-5xl font-extrabold text-gray-900 text-center mb-16 leading-tight">
          استكشف <span className="text-[#0D6EFD]">فئات منتجاتنا</span> الرئيسية
        </h1>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {categories.map((category, index) => (
            <a
              key={index}
              href={`/categories/${category.name}`} // رابط وهمي للفئة
              className="group bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 flex flex-col items-center p-8 border border-gray-100 hover:border-[#0D6EFD]/50"
            >
              <div className="mb-6 w-24 h-24 bg-[#0D6EFD] text-white rounded-full flex items-center justify-center text-5xl font-bold group-hover:bg-blue-800 transition-colors duration-300">
                {category.iconChar}
              </div>
              <h2 className="text-2xl font-semibold text-gray-800 mb-3 group-hover:text-[#0D6EFD] transition-colors duration-300">
                {category.name}
              </h2>
              <p className="text-gray-600 text-base leading-relaxed text-center">
                {category.description}
              </p>
            </a>
          ))}
        </div>
      </div>
    </div>
  );
}