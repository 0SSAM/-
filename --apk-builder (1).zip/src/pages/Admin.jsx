export default function AdminDashboard() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-700 text-white p-12">
      <h1 className="text-4xl font-bold mb-4">AdminDashboard</h1>
      <p className="text-lg text-slate-200">لوحة إدارة للمشرفين لإدارة المنتجات، الفئات، الطلبات، والمستخدمين، بالإضافة إلى مراجعة الاستشارات والشكاوى.</p>
    </div>
  );
}