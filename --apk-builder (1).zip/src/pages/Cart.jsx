import React from 'react';

export default function CartPage() {
  // Placeholder data for cart items
  const cartItems = [
    {
      id: 1,
      name: 'جهاز قياس السكر الذكي',
      description: 'جهاز متطور لمراقبة مستوى السكر في الدم بدقة وسهولة. يتضمن شاشة عرض كبيرة وذاكرة لتخزين القراءات.',
      price: 129.99,
      quantity: 1,
      image: 'https://via.placeholder.com/150/0D6EFD/FFFFFF?text=Glucose+Monitor',
    },
    {
      id: 2,
      name: 'مجموعة شرائط اختبار (50 شريط)',
      description: 'عبوة اقتصادية تحتوي على 50 شريط اختبار، متوافقة مع أجهزة قياس السكر الحديثة.',
      price: 29.50,
      quantity: 2,
      image: 'https://via.placeholder.com/150/0D6EFD/FFFFFF?text=Test+Strips',
    },
    {
      id: 3,
      name: 'جهاز قياس ضغط الدم الرقمي',
      description: 'سهل الاستخدام ويمنح قراءات دقيقة لضغط الدم والنبض. مثالي للاستخدام المنزلي.',
      price: 85.00,
      quantity: 1,
      image: 'https://via.placeholder.com/150/0D6EFD/FFFFFF?text=Blood+Pressure',
    },
  ];

  const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const shipping = 15.00; // Flat rate shipping
  const taxRate = 0.05; // 5% tax
  const tax = subtotal * taxRate;
  const total = subtotal + shipping + tax;

  return (
    <div className="min-h-screen bg-gray-50 p-4 sm:p-6 lg:p-8 font-sans antialiased text-right" dir="rtl">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl sm:text-4xl font-extrabold text-gray-900 mb-8 sm:mb-10 text-center">
          سلة التسوق
        </h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Cart Items Section */}
          <div className="lg:col-span-2 bg-white shadow-lg rounded-xl p-4 sm:p-6">
            <h2 className="text-2xl font-semibold text-gray-800 mb-6 border-b pb-4">
              المنتجات في سلتك ({cartItems.length})
            </h2>
            {cartItems.length === 0 ? (
              <p className="text-gray-600 text-lg text-center py-8">سلة التسوق فارغة.</p>
            ) : (
              <ul className="divide-y divide-gray-200">
                {cartItems.map((item) => (
                  <li key={item.id} className="flex flex-col sm:flex-row items-start sm:items-center py-6">
                    <div className="flex-shrink-0 w-24 h-24 sm:w-32 sm:h-32 rounded-lg overflow-hidden border border-gray-200 ml-4 mb-4 sm:mb-0">
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-full h-full object-cover object-center"
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="text-xl font-medium text-gray-900 mb-1">{item.name}</h3>
                      <p className="text-sm text-gray-600 mb-2">{item.description}</p>
                      <p className="text-lg font-bold text-gray-900">
                        {item.price.toFixed(2)} ر.س
                        <span className="text-gray-500 text-sm font-normal mr-1"> / لكل قطعة</span>
                      </p>
                      <div className="flex items-center mt-3">
                        <label htmlFor={`quantity-${item.id}`} className="sr-only">كمية {item.name}</label>
                        <button
                          type="button"
                          className="px-3 py-1 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#0D6EFD]"
                          aria-label={`تقليل كمية ${item.name}`}
                        >
                          -
                        </button>
                        <input
                          id={`quantity-${item.id}`}
                          type="number"
                          value={item.quantity}
                          min="1"
                          className="w-16 text-center border-t border-b border-gray-300 py-1 text-gray-900 text-lg font-medium focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#0D6EFD]"
                          readOnly // For this example, quantity is read-only. In a real app, it would be mutable.
                          aria-live="polite"
                          aria-atomic="true"
                        />
                        <button
                          type="button"
                          className="px-3 py-1 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#0D6EFD]"
                          aria-label={`زيادة كمية ${item.name}`}
                        >
                          +
                        </button>
                        <button
                          type="button"
                          className="ml-4 text-sm font-medium text-red-600 hover:text-red-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                          aria-label={`إزالة ${item.name} من السلة`}
                        >
                          إزالة
                        </button>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>

          {/* Order Summary Section */}
          <div className="lg:col-span-1 bg-white shadow-lg rounded-xl p-4 sm:p-6 h-fit">
            <h2 className="text-2xl font-semibold text-gray-800 mb-6 border-b pb-4">
              ملخص الطلب
            </h2>
            <div className="space-y-4">
              <div className="flex justify-between items-center text-gray-700">
                <span className="text-lg">المجموع الفرعي:</span>
                <span className="text-lg font-medium">{subtotal.toFixed(2)} ر.س</span>
              </div>
              <div className="flex justify-between items-center text-gray-700">
                <span className="text-lg">الشحن والتعامل:</span>
                <span className="text-lg font-medium">{shipping.toFixed(2)} ر.س</span>
              </div>
              <div className="flex justify-between items-center text-gray-700">
                <span className="text-lg">الضرائب ({(taxRate * 100).toFixed(0)}%):</span>
                <span className="text-lg font-medium">{tax.toFixed(2)} ر.س</span>
              </div>
              <div className="border-t border-gray-200 pt-4 flex justify-between items-center text-gray-900">
                <span className="text-xl font-bold">المبلغ الإجمالي:</span>
                <span className="text-xl font-extrabold text-[#0D6EFD]">{total.toFixed(2)} ر.س</span>
              </div>
            </div>
            <button
              type="button"
              className="mt-8 w-full bg-[#0D6EFD] text-white py-3 px-6 rounded-lg text-lg font-semibold hover:bg-blue-700 focus:outline-none focus:ring-4 focus:ring-[#0D6EFD] focus:ring-opacity-50 transition ease-in-out duration-150 shadow-md"
            >
              متابعة الدفع
            </button>
            <p className="mt-4 text-center text-sm text-gray-500">
              باستخدام هذه السلة، أنت توافق على <a href="#" className="text-[#0D6EFD] hover:underline">شروط الخدمة</a> لدينا.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}